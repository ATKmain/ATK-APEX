
-- run as user SYS:

-- required for NTLM utilities
grant execute on dbms_crypto to &&your_schema;



set scan off;


prompt Creating ORACLE APEX and OWA utility package specifications

@..\ora\apex_util_pkg.pks
@..\ora\owa_util_pkg.pks

prompt Creating ORACLE APEX and OWA utility package bodies

@..\ora\apex_util_pkg.pkb
@..\ora\owa_util_pkg.pkb


prompt Done!


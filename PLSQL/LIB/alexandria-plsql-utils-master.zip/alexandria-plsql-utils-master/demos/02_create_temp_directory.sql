
-- required for demos that read/write files on disk

CREATE DIRECTORY devtest_temp_dir AS 'c:\temp\devtest';


